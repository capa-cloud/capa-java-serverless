package group.rxcloud.capajavaserverless;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapaJavaServerlessApplicationTests {

	@Test
	void contextLoads() {
	}

}
