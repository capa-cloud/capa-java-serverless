package group.rxcloud.capajavaserverless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapaJavaServerlessApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapaJavaServerlessApplication.class, args);
	}

}
